#include <stdio.h>

int main() {

	int lines = 0;		
	printf("Enter the number of lines for punishment: ");
	scanf("%d", &lines);

	//printf("%d\n", lines);
	if(lines <= 0){
		printf("You have entered an incorrect value!\n");
	}
	else {

	for (int i = 0; i < lines; i++){
		printf("C is the best programming language!\n");
	}
}

	return 0;

}