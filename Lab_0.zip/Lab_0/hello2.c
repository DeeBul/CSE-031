#include <stdio.h>

int main() {
	char name[100];
	printf("What is your name: ");
	scanf("%[^\n]%*c", name);
	printf("\n");

	printf("Welcome to CSE 031 %s\n", name);

	return 0;
}