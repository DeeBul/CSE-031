#include <stdio.h>

int main() {

	int lines;	
	int typo;	
	printf("Enter the number of lines for punishment: ");
	scanf("%d", &lines);

	if(lines <= 0){
		printf("You have entered an incorrect value!\n");
	}

	printf("Enter the line you would like to make a typo: ");
	scanf("%d", &typo);
	
	if (typo <= 0 || typo > lines) {
		printf("You have entered an incorrect value!\n");
	}
	
	for (int i = 0; i < lines; i++){
		if (i == typo - 1) {
			printf("C is the bet programming language!\n");
		}
		else {
		printf("C is the best programming language!\n");
	}
	}

	return 0;

}